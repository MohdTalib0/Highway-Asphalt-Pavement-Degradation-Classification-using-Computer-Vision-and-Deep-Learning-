# Data Sourcing

<!--
**Rationale: ** This is a description of this tasks

**Citations: APA (7th edition) \
**
-->
## **Introduction**  
The main objective of this task is to source for datasets of Asphalt Pavement Degradation already made available for use various online repositories.  

## Datasets
###  **UAPD: UAV Asphalt Pavement Distress**
This [dataset](https://github.com/tantantetetao/UAPD-Pavement-Distress-Dataset) is publicly available and free to use, and upon review contains most of the commonly encountered asphalt degradation in our area of interest.

* Classes:
    * Transverse crack
    * Longitudinal crack 
    * Oblique crack
    * Alligator crack 
    * Repair 
    * Pothole  

Dataset contains 3151 distress images along with their annotations  
This dataset was selected during literature review. 
* [Citation 1](https://doi.org/10.1016/j.autcon.2021.103991)
* [Citation 2](https://doi.org/10.1016/j.autcon.2022.104436)

### **Tongzheng**
This [publicly available dataset](https://github.com/tongzheng1992/Pavementscapes) was also selected during literature review. The original dataset(1024x2048) was resized to 512x512 images.  
As labels did not already exist for the dataset, [LabelImg](https://github.com/heartexlabs/labelImg) was used to provide annotations.

* Classes:
    * Lateral Crack
    * Longitudinal Crack
    * Alligator Crack
    * Pothole
    * Repair Area
    * Rut

Dataset contains 4000 images in train/test/validation split of **5:2:1** and annotations have been completed.
* [Citation](https://arxiv.org/abs/2208.00775)