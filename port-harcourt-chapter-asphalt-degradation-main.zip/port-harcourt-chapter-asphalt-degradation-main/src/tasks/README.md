# Task Folder Details

Note: Please follow the guidelines below to create task folders as the project progresses:

- Task Folder Naming Convention: _task-n-taskname. (n is the task number)_  ex: task-1-data-analysis, task-2-model-deployment, etc.
- All Task folder names should be in chronological order (from 1 to n).
- All Task folders should have a README.md file with task details and task goals, along with an info table containing all code/notebook files with their links and information.
- Task folders that contain sub-tasks can create subfolders within the task.
- Update the table below to explain the task details.

### Task Table

| Task No | Task Name            | Details                                                                 |
| ------- | -------------------- | ----------------------------------------------------------------------- |
| 1       | Dataset Sourcing     | Team scouting for possible datasets that can be utilized for the project |
| 2       | Project Pipeline     | Establishing the project workflow and pipeline                           |
| 3       | Setting Timelines    | Defining and setting timelines for the project tasks                     |
| 4       | Data Preprocessing   | Preprocessing and cleaning the acquired dataset                          |
| 5       | Model Development    | Developing models for the identified tasks and objectives                |

Feel free to update the task table as the project progresses and add more details to the task folders.
