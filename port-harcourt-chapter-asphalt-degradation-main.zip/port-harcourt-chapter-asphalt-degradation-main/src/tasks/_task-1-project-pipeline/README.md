# Project Pipeline

<!--
**Rationale: ** This is a discription of this tasks

**Citations: APA (7th edition) \
**
-->
**Introduction**
The main objective of this task is to come up with a project development lifecyle/story line/or workflow for the overall challenge of Asphalt Pavement Degradation. This could be sketch as a diagram or outlined
	

**References:**
