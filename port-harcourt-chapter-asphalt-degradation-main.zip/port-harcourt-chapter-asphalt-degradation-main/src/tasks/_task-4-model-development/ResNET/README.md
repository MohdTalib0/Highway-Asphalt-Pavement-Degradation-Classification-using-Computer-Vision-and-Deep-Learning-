This folder will contain the model development activity for ResNET architecture including the notebooks and scripts as a task on the identified datasets.
