This folder will contain the model development activity for YoloV8 architecture including the notebooks and scripts as a task on the identified datasets.
