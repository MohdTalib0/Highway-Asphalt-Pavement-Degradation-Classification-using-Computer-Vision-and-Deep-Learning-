# Docs

## Team Members Project Details

[Asphalt Pavement Degradation Classification Team.xlsx](https://github.com/OmdenaAI/port-harcourt-chapter-asphalt-degradation/files/11308119/Asphalt.Pavement.Degradation.Classification.Team.xlsx)

## Final Project Result

[Results and metrics](https://docs.google.com/document/d/1SZ1vNSHybq_1-h_xrpS9BnTjqzwrlndm0oydPsb50WQ/edit?usp=sharing)

