# Data

## 1.) UAPD UAV Asphalt Pavement Distress Dataset

Link: https://drive.google.com/file/d/1yQ0GMXFwwM5qdYY_5HzJBQqqjNtWJxEc/view?usp=sharing

3151 pavement distress images for model training and testing

Classes: transverse crack, longitudinal crack, oblique crack, alligator crack, pothole and repair.

### Citation
1.Junqing Zhu, Jingtao Zhong, Tao Ma, Xiaoming Huang, Weiguang Zhang, Yang Zhou, Pavement distress detection using convolutional neural networks with images captured via UAV, Automation in Construction, Vol.133, 2022, https://doi.org/10.1016/j.autcon.2021.103991.

2.Jingtao Zhong, Junqing Zhu, Ju Huyan, Tao Ma, Weiguang Zhang, Multi-scale feature fusion network for pixel-level pavement distress detection, Automation in Construction, Vol.141, 2022, https://doi.org/10.1016/j.autcon.2022.104436.

### Copy Right
This Dataset has been released for public use.
